# Universal Volume Controller

Client-side volume control for all items and other sounds within the game

Tired of loud noises? Tired of your friends blasting the air horn in your ears? TURN IT OFF
Each individual item / sound can be lowered in volume or be fully muted.

## Features

- In-game menu toggle by pressing ```F10```
- Global volume slider with quick mute and unmute.
- Per-category controls for:
  - Item Sounds
  - Environment
  - Other
- Per-sound sliders inside each category so you can fine-tune specific sounds
- Category-wide Mute All and Unmute All actions
- Search box to quickly find sounds by name
- UI customization with theme color presets and opacity control
- Automatic runtime discovery and refresh for newly seen audio sources
- Saves settings between sessions within the same game (SWITCHING TO A NEW GAME DOESNT KEEP THE SETTINGS)

### Debug Hotkeys

- ```F9``` + ```F10```: Dump active audio sources to the log
- ```F9``` + ```F10``` + ```LeftCtrl```: Dump all audio sources (including non-playing)

## Notes

- This mod is designed for player-side control and does not synchronize volume values to other players

## Thunderstore Deployment Automation

This repo includes a GitHub Actions workflow at `.github/workflows/publish-thunderstore.yml`.

- Trigger: when a pull request is merged into the `deployment` branch
- Output package: `artifacts/UniversalVolumeController.zip`
- Zip contents (root):
  - `UniversalVolumeController.dll`
  - `README.md`
  - `manifest.json`
  - `icon.png`

### Required Repository Secret

Add this GitHub Actions secret in the repository settings:

- `THUNDERSTORE_TOKEN`: your Thunderstore service account token

### Notes About Building

The workflow attempts to build before packaging. If CI cannot build due local machine references, make sure a valid `UniversalVolumeController.dll` is available in one of these locations before packaging:

- `bin/Release/netstandard2.1/UniversalVolumeController.dll`
- `bin/Debug/netstandard2.1/UniversalVolumeController.dll`
- `UniversalVolumeController.dll`
